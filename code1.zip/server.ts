import dotenv from "dotenv";
import express from "express";
import fs from "fs";
import http from "http";
import https from "https";
import { createServer as createViteServer } from "vite";

dotenv.config({ path: ".env.local" });
dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;
  const sslKeyPath = process.env.SSL_KEY_PATH;
  const sslCertPath = process.env.SSL_CERT_PATH;
  const sslPfxPath = process.env.SSL_PFX_PATH;
  const sslPfxPassphrase = process.env.SSL_PFX_PASSPHRASE;

  // Increase payload limit for base64 images
  app.use(express.json({ limit: '50mb' }));

  // API routes FIRST
  app.post("/api/stream", (req, res) => {
    const { frame, location, timestamp } = req.body;
    
    // In a real application, you would save this frame and location to a database,
    // or stream it to an external service.
    // Here we log it to the server console to verify it's working.
    console.log(`[${new Date(timestamp).toISOString()}] Received frame from ${location ? `Lat: ${location.lat}, Lng: ${location.lng}` : 'unknown location'}`);
    
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  let server: http.Server | https.Server;
  let protocol = "http";

  if (sslPfxPath) {
    try {
      const pfx = fs.readFileSync(sslPfxPath);
      server = https.createServer(
        {
          pfx,
          passphrase: sslPfxPassphrase || undefined,
        },
        app
      );
      protocol = "https";
    } catch (error) {
      console.warn("HTTPS PFX could not be loaded, falling back to HTTP.", error);
      server = http.createServer(app);
    }
  } else if (sslKeyPath && sslCertPath) {
    try {
      const sslOptions = {
        key: fs.readFileSync(sslKeyPath),
        cert: fs.readFileSync(sslCertPath),
      };
      server = https.createServer(sslOptions, app);
      protocol = "https";
    } catch (error) {
      console.warn("HTTPS cert/key could not be loaded, falling back to HTTP.", error);
      server = http.createServer(app);
    }
  } else {
    server = http.createServer(app);
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on ${protocol}://localhost:${PORT}`);
  });
}

startServer();
