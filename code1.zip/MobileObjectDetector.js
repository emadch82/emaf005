/**
 * MobileObjectDetector.js
 *
 * Port of ObjectsDetectionServiceClasicV2.cs → Mobile Browser (WebGL + TypedArrays)
 *
 * جایگزینی CUDA/CPU Parallel با:
 *   ▸ WebGL2 Shaders  → پردازش پیکسلی روی GPU موبایل (AbsDiff, Threshold, Mask)
 *   ▸ Float32Array    → بافر میانگین متحرک روی CPU
 *   ▸ Separable Morphology → Open/Close با kernel جداپذیر (بهینه موبایل)
 *   ▸ Two-Pass Connected Components → جایگزین FindContours
 *
 * الگوریتم اصلی (عین C# اصلی):
 *   1. gray   = grayscale(frame)
 *   2. diff   = |gray - avgImages|
 *   3. thresh = |avgDiffImgs * c + b|
 *   4. mask   = diff > thresh  →  255 / 0
 *   5. morphOpen(mask, 2×2)   → حذف نویز
 *   6. morphClose(mask, 41×41) → پر کردن شکاف
 *   7. findBlobs → BoundingBox + Center
 *   8. updateRollingAverage(gray, diff)
 *
 * استفاده:
 *   const detector = new MobileObjectDetector();
 *   await detector.init(videoElement, { c: 1.0, b: 5 });
 *   const objects = detector.processFrame(videoElement);
 *   // objects = [{ x, y, w, h, cx, cy, area }, ...]
 */

'use strict';

export class MobileObjectDetector {

  /* ─────────────────────────── PUBLIC API ─────────────────────────── */

  constructor() {
    this._p   = null;   // params
    this._gl  = null;   // WebGL2 context
    this._sh  = null;   // compiled shaders program
    this._fb  = null;   // framebuffer objects
    this._tex = null;   // textures
    this._useWebGL = false;
  }

  /**
   * @param {HTMLVideoElement|HTMLCanvasElement} source
   * @param {object} options
   *   countOfImages   int    تعداد فریم در بافر میانگین          (default 5)
   *   maxContours     int    حداکثر اشیاء برگشتی                 (default 100)
   *   c               float  ضریب واریانس برای آستانه تطبیقی    (default 1.0)
   *   b               float  بایاس ثابت آستانه                   (default 5)
   *   openKernel      int    اندازه kernel erosion/dilation Open  (default 2)
   *   closeKernel     int    اندازه kernel دilation/erosion Close (default 21)
   *   minArea         int    حداقل مساحت blob برای پذیرش        (default 4)
   */
  async init(source, options = {}) {
    const W = source.videoWidth  || source.width;
    const H = source.videoHeight || source.height;

    const {
      countOfImages = 5,
      maxContours   = 100,
      c             = 1.0,
      b             = 5,
      openKernel    = 2,
      closeKernel   = 21,   // ←  41 خیلی سنگینه، 21 برای موبایل کافیه
      minArea       = 4,
    } = options;

    const N = W * H;

    this._p = {
      W, H, N,
      countOfImages,
      maxContours,
      c, b,
      openKernel,
      closeKernel,
      minArea,
      index: 0,
      frameCount: 0,

      // rolling buffers (CPU)
      images:    Array.from({ length: countOfImages }, () => new Float32Array(N)),
      diffImgs:  Array.from({ length: countOfImages }, () => new Float32Array(N)),
      avgImages:    new Float32Array(N),  // avg of frames
      avgDiffImgs:  new Float32Array(N),  // avg of |diff|

      // output buffers reused per frame
      gray:   new Float32Array(N),
      diff:   new Float32Array(N),
      mask:   new Uint8Array(N),
      opened: new Uint8Array(N),
      closed: new Uint8Array(N),
    };

    // Try WebGL2 for GPU-accelerated pixel ops
    this._tryInitWebGL(W, H);

    return this;
  }

  /**
   * پردازش یک فریم و برگرداندن لیست اشیاء تشخیص داده شده
   * @param {HTMLVideoElement|HTMLCanvasElement|ImageData} source
   * @returns {DetectedObject[]}
   */
  processFrame(source) {
    const p = this._p;
    if (!p) throw new Error('MobileObjectDetector: call init() first');

    // --- Step 1: grayscale float [0–255] ---
    const imageData = this._getImageData(source);
    this._toGrayscale(imageData.data, p.gray);

    if (this._useWebGL) {
      this._gpuMaskPass(p.gray, p.avgImages, p.avgDiffImgs, p.c, p.b, p.mask);
    } else {
      this._cpuDiffAndMask(p);
    }

    // --- Step 5 & 6: Morphological Open then Close ---
    this._morphOpen(p.mask, p.opened, p.W, p.H, p.openKernel);
    this._morphClose(p.opened, p.closed, p.W, p.H, p.closeKernel);

    // --- Step 7: Update rolling averages ---
    this._updateAverages(p);

    p.frameCount++;

    // --- Step 8: Find blobs ---
    // اولین countOfImages فریم رو skip میکنیم تا avg آماده بشه
    if (p.frameCount <= p.countOfImages) return [];

    return this._findBlobs(p.closed, p.W, p.H, p.maxContours, p.minArea);
  }

  /** آزادسازی منابع WebGL */
  dispose() {
    const gl = this._gl;
    if (!gl) return;
    if (this._sh)  { gl.deleteProgram(this._sh); }
    if (this._tex) { Object.values(this._tex).forEach(t => gl.deleteTexture(t)); }
    if (this._fb)  { Object.values(this._fb).forEach(f => gl.deleteFramebuffer(f)); }
    this._gl = null;
    this._p  = null;
  }

  /* ─────────────────────── GRAYSCALE ──────────────────────────────── */

  _toGrayscale(rgba, out) {
    // ITU-R BT.601 – همان روش OpenCV
    const N = out.length;
    for (let i = 0; i < N; i++) {
      const o = i << 2;
      out[i] = 0.299 * rgba[o] + 0.587 * rgba[o + 1] + 0.114 * rgba[o + 2];
    }
  }

  /* ─────────────────── CPU DIFF + MASK (بدون WebGL) ──────────────── */

  /**
   * معادل دقیق ProcessImagesParallel در C# اصلی (اما single-thread)
   * diff   = |gray - avgImages|
   * thresh = |avgDiffImgs * c + b|
   * mask   = diff > thresh  →  255
   */
  _cpuDiffAndMask(p) {
    const { gray, diff, mask, avgImages, avgDiffImgs, N, c, b } = p;
    for (let i = 0; i < N; i++) {
      const d = Math.abs(gray[i] - avgImages[i]);
      diff[i] = d;
      const t = Math.abs(avgDiffImgs[i] * c + b);
      mask[i] = d > t ? 255 : 0;
    }
  }

  /* ─────────────────────── ROLLING AVERAGE ────────────────────────── */

  /**
   * معادل دقیق منطق C#:
   *   avg_images  += (I    - images[index])   / N
   *   avg_DiffImgs += (diff - diffImgs[index]) / N
   */
  _updateAverages(p) {
    const { gray, diff, images, diffImgs, avgImages, avgDiffImgs, index, countOfImages, N } = p;
    const inv = 1.0 / countOfImages;

    for (let i = 0; i < N; i++) {
      avgImages[i]   += (gray[i]  - images[index][i])   * inv;
      avgDiffImgs[i] += (diff[i]  - diffImgs[index][i]) * inv;
    }

    // ذخیره فریم فعلی در بافر چرخشی
    images[index].set(gray);
    diffImgs[index].set(diff);

    p.index = (index + 1) % countOfImages;
  }

  /* ──────────────────── MORPHOLOGY (CPU Separable) ────────────────── */
  //
  // روش جداپذیر (Separable): هر kernel مربعی رو به دو pass
  //   - افقی (row pass)
  //   - عمودی (col pass)
  // تبدیل میکنیم → از O(k²) به O(k) کاهش میده، ایده‌آل موبایل
  //

  _morphErode(src, dst, W, H, k) {
    const tmp = new Uint8Array(W * H);
    const r   = k >> 1;

    // pass افقی
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let min = 255;
        const x0 = Math.max(0, x - r);
        const x1 = Math.min(W - 1, x + r);
        for (let xx = x0; xx <= x1; xx++) {
          if (src[y * W + xx] === 0) { min = 0; break; }
        }
        tmp[y * W + x] = min;
      }
    }

    // pass عمودی
    for (let x = 0; x < W; x++) {
      for (let y = 0; y < H; y++) {
        let min = 255;
        const y0 = Math.max(0, y - r);
        const y1 = Math.min(H - 1, y + r);
        for (let yy = y0; yy <= y1; yy++) {
          if (tmp[yy * W + x] === 0) { min = 0; break; }
        }
        dst[y * W + x] = min;
      }
    }
  }

  _morphDilate(src, dst, W, H, k) {
    const tmp = new Uint8Array(W * H);
    const r   = k >> 1;

    // pass افقی
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let max = 0;
        const x0 = Math.max(0, x - r);
        const x1 = Math.min(W - 1, x + r);
        for (let xx = x0; xx <= x1; xx++) {
          if (src[y * W + xx] === 255) { max = 255; break; }
        }
        tmp[y * W + x] = max;
      }
    }

    // pass عمودی
    for (let x = 0; x < W; x++) {
      for (let y = 0; y < H; y++) {
        let max = 0;
        const y0 = Math.max(0, y - r);
        const y1 = Math.min(H - 1, y + r);
        for (let yy = y0; yy <= y1; yy++) {
          if (tmp[yy * W + x] === 255) { max = 255; break; }
        }
        dst[y * W + x] = max;
      }
    }
  }

  /** Open = Erode → Dilate  (حذف نقاط نویز کوچک) */
  _morphOpen(src, dst, W, H, k) {
    const tmp = new Uint8Array(W * H);
    this._morphErode(src, tmp, W, H, k);
    this._morphDilate(tmp, dst, W, H, k);
  }

  /** Close = Dilate → Erode  (پر کردن شکاف‌های کوچک) */
  _morphClose(src, dst, W, H, k) {
    const tmp = new Uint8Array(W * H);
    this._morphDilate(src, tmp, W, H, k);
    this._morphErode(tmp, dst, W, H, k);
  }

  /* ──────────────────── CONNECTED COMPONENTS (Blob) ──────────────── */
  //
  // جایگزین FindContours + BoundingRectangle در C# اصلی.
  // الگوریتم Two-Pass label بدون ساختار Union-Find سبک.
  //

  _findBlobs(mask, W, H, maxBlobs, minArea) {
    const labels  = new Int32Array(W * H);  // 0 = background
    const bboxes  = [];
    let   nextLbl = 1;

    // Pass 1: label گذاری با flood fill ساده (stack-based BFS)
    const stack = [];
    for (let i = 0; i < W * H; i++) {
      if (mask[i] === 255 && labels[i] === 0) {
        const lbl = nextLbl++;
        stack.push(i);
        labels[i] = lbl;

        let minX = W, maxX = 0, minY = H, maxY = 0, area = 0;

        while (stack.length > 0) {
          const idx = stack.pop();
          const px  = idx % W;
          const py  = (idx - px) / W;

          if (px < minX) minX = px;
          if (px > maxX) maxX = px;
          if (py < minY) minY = py;
          if (py > maxY) maxY = py;
          area++;

          // 4-connectivity (همسایگان بالا/پایین/چپ/راست)
          const neighbors = [
            idx - W,        // بالا
            idx + W,        // پایین
            px > 0   ? idx - 1 : -1,  // چپ
            px < W-1 ? idx + 1 : -1,  // راست
          ];

          for (const n of neighbors) {
            if (n >= 0 && n < W * H && mask[n] === 255 && labels[n] === 0) {
              labels[n] = lbl;
              stack.push(n);
            }
          }
        }

        if (area >= minArea) {
          bboxes.push({
            x:    minX,
            y:    minY,
            w:    maxX - minX + 1,
            h:    maxY - minY + 1,
            cx:   Math.round((minX + maxX) / 2),
            cy:   Math.round((minY + maxY) / 2),
            area,
          });
        }

        if (bboxes.length >= maxBlobs) break;
      }
    }

    return bboxes;
  }

  /* ─────────────────── WebGL GPU ACCELERATION ────────────────────── */
  //
  // این بخش پردازش AbsDiff + Threshold رو روی GPU موبایل انجام میده.
  // در صورت عدم پشتیبانی، به CPU fallback میشه.
  //

  _tryInitWebGL(W, H) {
    try {
      const canvas = document.createElement('canvas');
      canvas.width  = W;
      canvas.height = H;

      const gl = canvas.getContext('webgl2');
      if (!gl) { this._useWebGL = false; return; }

      // بررسی پشتیبانی float texture
      const ext = gl.getExtension('EXT_color_buffer_float');
      if (!ext) { this._useWebGL = false; return; }

      this._gl = gl;
      this._glCanvas = canvas;

      // ────── Vertex Shader (full-screen quad) ──────
      const VS = `#version 300 es
        in vec2 a_pos;
        out vec2 v_uv;
        void main() {
          v_uv = a_pos * 0.5 + 0.5;
          gl_Position = vec4(a_pos, 0.0, 1.0);
        }`;

      // ────── Fragment Shader ──────
      // diff   = |current - avgImages|
      // thresh = |avgDiffImgs * c + b|
      // mask   = diff > thresh ? 1.0 : 0.0
      const FS = `#version 300 es
        precision highp float;
        uniform sampler2D u_current;
        uniform sampler2D u_avgImages;
        uniform sampler2D u_avgDiff;
        uniform float     u_c;
        uniform float     u_b;
        in  vec2 v_uv;
        out vec4 fragColor;
        void main() {
          float cur  = texture(u_current,  v_uv).r;
          float avg  = texture(u_avgImages, v_uv).r;
          float adf  = texture(u_avgDiff,   v_uv).r;
          float diff  = abs(cur - avg);
          float thr   = abs(adf * u_c + u_b);
          float m     = diff > thr ? 1.0 : 0.0;
          fragColor   = vec4(m, m, m, 1.0);
        }`;

      const prog = this._compileProgram(gl, VS, FS);
      if (!prog) { this._useWebGL = false; return; }

      this._sh = prog;

      // full-screen quad
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER,
        new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
      this._quadBuf = buf;

      // textures
      this._tex = {
        current:   this._createTexF32(gl, W, H),
        avgImages: this._createTexF32(gl, W, H),
        avgDiff:   this._createTexF32(gl, W, H),
        mask:      this._createTexF32(gl, W, H),
      };

      // framebuffer
      const fb = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0,
        gl.TEXTURE_2D, this._tex.mask, 0);

      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
        this._useWebGL = false; return;
      }

      this._fb = fb;
      this._useWebGL = true;

    } catch (e) {
      console.warn('MobileObjectDetector: WebGL not available, using CPU fallback.', e);
      this._useWebGL = false;
    }
  }

  _gpuMaskPass(gray, avgImages, avgDiffImgs, c, b, maskOut) {
    const gl = this._gl;
    const { W, H, N } = this._p;

    // آپلود textures
    this._uploadTexF32(gl, this._tex.current,   gray,        W, H);
    this._uploadTexF32(gl, this._tex.avgImages,  avgImages,   W, H);
    this._uploadTexF32(gl, this._tex.avgDiff,    avgDiffImgs, W, H);

    gl.bindFramebuffer(gl.FRAMEBUFFER, this._fb);
    gl.viewport(0, 0, W, H);
    gl.useProgram(this._sh);

    // uniforms
    gl.uniform1f(gl.getUniformLocation(this._sh, 'u_c'), c);
    gl.uniform1f(gl.getUniformLocation(this._sh, 'u_b'), b);

    // texture units
    this._bindTex(gl, this._tex.current,   0, 'u_current');
    this._bindTex(gl, this._tex.avgImages, 1, 'u_avgImages');
    this._bindTex(gl, this._tex.avgDiff,   2, 'u_avgDiff');

    // quad
    gl.bindBuffer(gl.ARRAY_BUFFER, this._quadBuf);
    const loc = gl.getAttribLocation(this._sh, 'a_pos');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    // readback to CPU Uint8Array
    const raw = new Float32Array(N * 4);
    gl.readPixels(0, 0, W, H, gl.RGBA, gl.FLOAT, raw);
    for (let i = 0; i < N; i++) {
      maskOut[i] = raw[i * 4] > 0.5 ? 255 : 0;
    }

    // حساب diff هم لازمه برای rolling average – روی CPU
    const { gray: g, avgImages: ai, diff } = this._p;
    for (let i = 0; i < N; i++) {
      diff[i] = Math.abs(g[i] - ai[i]);
    }
  }

  _createTexF32(gl, W, H) {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R32F, W, H, 0, gl.RED, gl.FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }

  _uploadTexF32(gl, tex, data, W, H) {
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, W, H, gl.RED, gl.FLOAT, data);
  }

  _bindTex(gl, tex, unit, name) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.uniform1i(gl.getUniformLocation(this._sh, name), unit);
  }

  _compileProgram(gl, vsrc, fsrc) {
    const compile = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        console.error('Shader error:', gl.getShaderInfoLog(s));
        return null;
      }
      return s;
    };
    const vs = compile(gl.VERTEX_SHADER,   vsrc);
    const fs = compile(gl.FRAGMENT_SHADER, fsrc);
    if (!vs || !fs) return null;
    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('Link error:', gl.getProgramInfoLog(prog));
      return null;
    }
    return prog;
  }

  /* ─────────────────────── IMAGE DATA ────────────────────────────── */

  _getImageData(source) {
    if (source instanceof ImageData) return source;

    const { W, H } = this._p;
    if (!this._offscreen) {
      this._offscreen    = document.createElement('canvas');
      this._offscreen.width  = W;
      this._offscreen.height = H;
      this._offCtx = this._offscreen.getContext('2d', { willReadFrequently: true });
    }
    this._offCtx.drawImage(source, 0, 0, W, H);
    return this._offCtx.getImageData(0, 0, W, H);
  }
}

/* ════════════════════════════════════════════════════════════════════
   AngleCalculator
   محاسبه زاویه افقی و عمودی هر شیء نسبت به مرکز تصویر و افق
   (معادل الگوریتم C++ شما که در پروژه اشاره شده)
════════════════════════════════════════════════════════════════════ */

export class AngleCalculator {

  /**
   * @param {number} hFOV  زاویه دید افقی دوربین (درجه)   – مثلاً 60
   * @param {number} vFOV  زاویه دید عمودی دوربین (درجه)  – مثلاً 45
   * @param {number} W     عرض فریم به پیکسل
   * @param {number} H     ارتفاع فریم به پیکسل
   */
  constructor(hFOV = 60, vFOV = 45, W = 640, H = 480) {
    this.hFOV = hFOV;
    this.vFOV = vFOV;
    this.W    = W;
    this.H    = H;
  }

  /**
   * محاسبه زاویه‌های افقی و عمودی یک شیء
   * @param {number} cx  مرکز X شیء (پیکسل)
   * @param {number} cy  مرکز Y شیء (پیکسل)
   * @param {object} sensorData  { azimuth, pitch, roll } – از Device Orientation API
   * @returns {{ azimuthOffset, elevationOffset, absoluteAzimuth, absoluteElevation }}
   */
  calculate(cx, cy, sensorData = {}) {
    // فاصله از مرکز تصویر (normalized: -0.5 تا +0.5)
    const dx = (cx - this.W / 2) / this.W;
    const dy = (cy - this.H / 2) / this.H;

    // زاویه افقی و عمودی نسبت به محور دوربین (درجه)
    const hAngle = dx * this.hFOV;   // + = راست فریم
    const vAngle = -dy * this.vFOV;  // + = بالای فریم (Y معکوسه)

    // اگر داده سنسور موجود باشه، زاویه مطلق جغرافیایی رو هم حساب کن
    let absoluteAzimuth   = null;
    let absoluteElevation = null;

    if (sensorData.azimuth !== undefined) {
      // Azimuth: جهت شمال + offset افقی
      absoluteAzimuth   = (sensorData.azimuth   + hAngle + 360) % 360;
      // Elevation: pitch + offset عمودی
      absoluteElevation =  sensorData.pitch      + vAngle;
    }

    return {
      azimuthOffset:   hAngle,           // زاویه افقی نسبت به مرکز دوربین (°)
      elevationOffset: vAngle,           // زاویه عمودی نسبت به مرکز دوربین (°)
      absoluteAzimuth,                   // سمت جغرافیایی (° از شمال)
      absoluteElevation,                 // ارتفاع از افق (°)
      pixelX: cx,
      pixelY: cy,
    };
  }
}

/* ════════════════════════════════════════════════════════════════════
   NightVisionFilter
   فیلتر دید در شب: grayscale با contrast تقویت‌شده + نقاط سفید پررنگ
════════════════════════════════════════════════════════════════════ */

export class NightVisionFilter {

  /**
   * @param {number} threshold  آستانه روشنایی نقاط (0-255)   (default 180)
   * @param {number} boost      ضریب تقویت کنتراست              (default 2.0)
   */
  constructor(threshold = 180, boost = 2.0) {
    this.threshold = threshold;
    this.boost     = boost;
  }

  /**
   * اعمال فیلتر روی ImageData و برگرداندن ImageData جدید
   * @param {ImageData} imageData
   * @returns {ImageData}
   */
  apply(imageData) {
    const d   = imageData.data;
    const out = new Uint8ClampedArray(d.length);

    for (let i = 0; i < d.length; i += 4) {
      // Grayscale
      const gray = Math.min(255,
        (0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]) * this.boost);

      // نقاط خیلی روشن → سفید خالص (ستاره/جسم درخشان)
      const bright = gray >= this.threshold ? 255 : gray;

      out[i]   = bright;
      out[i+1] = bright;
      out[i+2] = bright;
      out[i+3] = 255;
    }

    return new ImageData(out, imageData.width, imageData.height);
  }
}
