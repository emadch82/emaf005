import { useState, useEffect, useRef } from 'react';
import { Camera, List, PlusCircle, Image as ImageIcon, Trash2, X, FlipHorizontal, Upload, MapPin, Film, Compass, ShieldAlert } from 'lucide-react';
import { Report, FrameData } from './types';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix leaflet icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

function LocationMarker({ position, setPosition }: { position: {lat: number, lng: number} | null, setPosition: (pos: {lat: number, lng: number}) => void }) {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });

  return position === null ? null : (
    <Marker position={position}></Marker>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'new' | 'list'>('home');
  const [reports, setReports] = useState<Report[]>([]);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [streamedFrames, setStreamedFrames] = useState<string[]>([]);
  const [recordedFrames, setRecordedFrames] = useState<FrameData[]>([]);

  // Camera state
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [tempLocation, setTempLocation] = useState<{lat: number, lng: number} | null>(null);
  
  // Sensor state
  const [sensors, setSensors] = useState<{x: number, y: number, z: number, heading: number | null} | null>(null);
  const [isSensorActive, setIsSensorActive] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [isRequestingPermissions, setIsRequestingPermissions] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const streamIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const sensorsRef = useRef<{x: number, y: number, z: number, heading: number | null} | null>(null);

  useEffect(() => {
    sensorsRef.current = sensors;
  }, [sensors]);

  useEffect(() => {
    const hasGranted = localStorage.getItem('permissions_granted');
    if (!hasGranted) {
      setShowPermissionModal(true);
    }
  }, []);

  const handleGrantPermissions = async () => {
    setIsRequestingPermissions(true);
    
    const promises: Promise<any>[] = [];

    // 1. Sensor Permission (iOS requires this to be synchronous with the click)
    if (typeof (window as any).DeviceOrientationEvent !== 'undefined' && typeof (window as any).DeviceOrientationEvent.requestPermission === 'function') {
      promises.push(
        (window as any).DeviceOrientationEvent.requestPermission().catch((e: any) => console.error("Sensor permission error", e))
      );
    }

    // 2. Camera Permission
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      promises.push(
        navigator.mediaDevices.getUserMedia({ video: true })
          .then(stream => stream.getTracks().forEach(track => track.stop()))
          .catch(e => console.error("Camera permission error", e))
      );
    }
    
    // 3. Geolocation Permission
    if ('geolocation' in navigator) {
      promises.push(
        new Promise<void>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            () => resolve(),
            () => resolve(),
            { enableHighAccuracy: true, timeout: 15000 }
          );
        })
      );
    }

    // Wait for all permission prompts to be handled by the user
    await Promise.allSettled(promises);

    localStorage.setItem('permissions_granted', 'true');
    setIsRequestingPermissions(false);
    setShowPermissionModal(false);
  };

  const handleOrientation = (event: DeviceOrientationEvent) => {
    let heading = null;
    if ('webkitCompassHeading' in event) {
      heading = (event as any).webkitCompassHeading;
    } else if (event.absolute && event.alpha !== null) {
      heading = 360 - event.alpha;
    }

    setSensors({
      x: event.beta || 0,
      y: event.gamma || 0,
      z: event.alpha || 0,
      heading: heading
    });
  };

  const startSensors = async () => {
    if (typeof (window as any).DeviceOrientationEvent !== 'undefined' && typeof (window as any).DeviceOrientationEvent.requestPermission === 'function') {
      try {
        const permissionState = await (window as any).DeviceOrientationEvent.requestPermission();
        if (permissionState === 'granted') {
          window.addEventListener('deviceorientation', handleOrientation);
          setIsSensorActive(true);
        } else {
          alert('مجوز دسترسی به سنسورها داده نشد. لطفاً از تنظیمات مرورگر دسترسی را فعال کنید.');
        }
      } catch (error) {
        console.error(error);
        alert('خطا در درخواست دسترسی به سنسورها.');
      }
    } else {
      window.addEventListener('deviceorientation', handleOrientation);
      setIsSensorActive(true);
    }
  };

  const stopSensors = () => {
    window.removeEventListener('deviceorientation', handleOrientation);
    setIsSensorActive(false);
    setSensors(null);
  };

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (streamIntervalRef.current) {
        clearInterval(streamIntervalRef.current);
      }
      window.removeEventListener('deviceorientation', handleOrientation);
    };
  }, []);

  // Ensure stream is attached to video element when camera opens
  useEffect(() => {
    if (isCameraOpen && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
    }
  }, [isCameraOpen]);

  useEffect(() => {
    const savedReports = localStorage.getItem('visual_reports');
    if (savedReports) {
      try {
        setReports(JSON.parse(savedReports));
      } catch (e) {
        console.error('Failed to parse reports', e);
      }
    }
  }, []);

  const saveReports = (newReports: Report[]) => {
    setReports(newReports);
    localStorage.setItem('visual_reports', JSON.stringify(newReports));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || (imagePreviews.length === 0 && streamedFrames.length === 0 && recordedFrames.length === 0)) return;

    const newReport: Report = {
      id: Date.now().toString(),
      title,
      description,
      imageUrls: imagePreviews,
      streamedFrames: streamedFrames,
      recordedFrames: recordedFrames,
      location: location,
      sensors: sensors,
      timestamp: Date.now(),
    };

    saveReports([newReport, ...reports]);
    
    // Reset form
    setTitle('');
    setDescription('');
    setImagePreviews([]);
    setStreamedFrames([]);
    setRecordedFrames([]);
    setLocation(null);
    stopSensors();
    setActiveTab('list');
  };

  const handleDelete = (id: string) => {
    saveReports(reports.filter(r => r.id !== id));
  };

  const startStreaming = (loc: {lat: number, lng: number} | null) => {
    if (streamIntervalRef.current) clearInterval(streamIntervalRef.current);
    setIsStreaming(true);
    
    streamIntervalRef.current = setInterval(() => {
      if (videoRef.current && videoRef.current.readyState >= 2) {
        const canvas = document.createElement('canvas');
        const scale = 0.5; // Reduce resolution for 4fps streaming
        canvas.width = videoRef.current.videoWidth * scale;
        canvas.height = videoRef.current.videoHeight * scale;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          if (facingMode === 'user') {
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
          }
          ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
          const frameData = canvas.toDataURL('image/jpeg', 0.4);
          
          const currentSensors = sensorsRef.current;
          setRecordedFrames(prev => [...prev, { image: frameData, sensors: currentSensors }].slice(-120)); // Keep last 120 frames (30s) for display
          
          fetch('/api/stream', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              frame: frameData,
              location: loc,
              timestamp: Date.now()
            })
          }).catch(e => console.error("Stream error:", e));
        }
      }
    }, 250); // 4 FPS
  };

  const startCamera = async (mode = facingMode) => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert("مرورگر شما از قابلیت دوربین پشتیبانی نمی‌کند. لطفاً از مرورگر کروم یا سافاری استفاده کنید.");
      return;
    }

    try {
      let stream;
      try {
        // ابتدا تلاش برای باز کردن دوربین با جهت مشخص شده (جلو یا عقب)
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: mode }
        });
      } catch (e: any) {
        console.warn("Specific facingMode failed, falling back to default video", e);
        
        // اگر خطای دسترسی نبود، سعی کن هر دوربینی را باز کنی
        if (e.name !== 'NotAllowedError' && e.name !== 'PermissionDeniedError') {
          stream = await navigator.mediaDevices.getUserMedia({
            video: true
          });
        } else {
          throw e; // اگر خطای دسترسی بود، آن را به بلاک catch اصلی بفرست
        }
      }

      streamRef.current = stream;
      setFacingMode(mode);
      setIsCameraOpen(true);
      
      // If video element is already rendered (e.g., when toggling camera)
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      // Start location and streaming
      startSensors();
      if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const loc = { lat: position.coords.latitude, lng: position.coords.longitude };
            setLocation(loc);
            startStreaming(loc);
          },
          (error) => {
            console.error("Location error:", error);
            startStreaming(null);
          },
          { enableHighAccuracy: true }
        );
      } else {
        startStreaming(null);
      }
    } catch (err: any) {
      console.error("Error accessing camera:", err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.message === 'Permission denied') {
        alert("دسترسی به دوربین مسدود شده است! \n\n۱. روی آیکون قفل (🔒) یا تنظیمات در کنار آدرس سایت (بالای مرورگر) کلیک کنید.\n۲. وارد بخش Permissions (مجوزها) شوید.\n۳. دسترسی Camera (دوربین) را روی Allow (مجاز) تنظیم کنید.\n۴. صفحه را رفرش کنید.");
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        alert("هیچ دوربینی روی دستگاه شما پیدا نشد!");
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        alert("دوربین شما توسط برنامه دیگری در حال استفاده است. لطفاً برنامه‌های دیگر را ببندید.");
      } else {
        alert(`خطا در باز کردن دوربین: ${err.message || err.name || 'نامشخص'}`);
      }
    }
  };

  const stopCamera = () => {
    if (streamIntervalRef.current) {
      clearInterval(streamIntervalRef.current);
      streamIntervalRef.current = null;
    }
    setIsStreaming(false);
    stopSensors();
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraOpen(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && videoRef.current.readyState >= 2) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        if (facingMode === 'user') {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setImagePreviews(prev => [...prev, dataUrl]);
      }
    }
  };

  const toggleCamera = () => {
    startCamera(facingMode === 'environment' ? 'user' : 'environment');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <button onClick={() => setActiveTab('home')} className="flex items-center gap-2 text-indigo-600 hover:text-indigo-700 transition-colors text-right">
            <Camera className="w-6 h-6" />
            <h1 className="text-xl font-semibold tracking-tight">گزارش‌گر تصویری</h1>
          </button>
          <nav className="flex gap-1">
            <button
              onClick={() => setActiveTab('new')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                activeTab === 'new'
                  ? 'bg-indigo-50 text-indigo-700'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">ثبت گزارش</span>
            </button>
            <button
              onClick={() => setActiveTab('list')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                activeTab === 'list'
                  ? 'bg-indigo-50 text-indigo-700'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">گزارش‌های من</span>
            </button>
          </nav>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8" dir="rtl">
        {isCameraOpen && (
          <div className="fixed inset-0 z-50 bg-black flex flex-col" dir="ltr">
            <div className="flex justify-between items-center p-4 text-white z-10 absolute top-0 w-full bg-gradient-to-b from-black/60 to-transparent">
              <button onClick={stopCamera} className="p-3 rounded-full bg-black/20 backdrop-blur-sm hover:bg-black/40 transition-colors">
                <X className="w-6 h-6" />
              </button>
              <button onClick={toggleCamera} className="p-3 rounded-full bg-black/20 backdrop-blur-sm hover:bg-black/40 transition-colors">
                <FlipHorizontal className="w-6 h-6" />
              </button>
            </div>
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/40 backdrop-blur-sm px-3 py-1.5 rounded-full text-white text-xs z-20" dir="rtl">
              <div className={`w-2 h-2 rounded-full ${isStreaming ? 'bg-red-500 animate-pulse' : 'bg-slate-400'}`}></div>
              <span>پخش زنده</span>
              {location && (
                <div className="flex items-center gap-1 mr-2 border-r border-white/30 pr-2">
                  <MapPin className="w-3 h-3" />
                  <span>مکان‌یابی شد</span>
                </div>
              )}
            </div>
            
            {sensors && (
              <div className="absolute top-14 left-4 flex flex-col gap-1 bg-black/40 backdrop-blur-sm px-3 py-2 rounded-lg text-white text-[10px] font-mono z-20 shadow-lg border border-white/10" dir="ltr">
                <div className="flex items-center gap-1.5 mb-1 text-emerald-400 border-b border-white/20 pb-1">
                  <Compass className="w-3 h-3" />
                  <span className="font-sans font-medium text-xs">سنسورها (زنده)</span>
                </div>
              <div className="flex justify-between gap-3"><span>X (Pitch):</span> <span>{sensors.x.toFixed(2)}°</span></div>
                <div className="flex justify-between gap-3"><span>Y (Roll):</span> <span>{sensors.y.toFixed(2)}°</span></div>
                <div className="flex justify-between gap-3"><span>Z (Yaw):</span> <span>{sensors.z.toFixed(2)}°</span></div>
                <div className="flex justify-between gap-3 text-emerald-300"><span>Heading:</span> <span>{sensors.heading !== null ? `${sensors.heading.toFixed(2)}°` : '-'}</span></div>
              </div>
            )}

            <video
              ref={videoRef}
              autoPlay
              playsInline
              className={`flex-1 w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />
            <div className="absolute bottom-0 w-full p-8 flex flex-col items-center bg-gradient-to-t from-black/60 to-transparent">
              <div className="flex items-center justify-between w-full max-w-xs">
                <div className="w-12 h-12">
                  {/* Empty div for flex spacing */}
                </div>
                <button
                  onClick={capturePhoto}
                  className="w-20 h-20 rounded-full border-4 border-white bg-white/20 flex items-center justify-center active:bg-white/40 transition-colors shadow-lg"
                >
                  <div className="w-16 h-16 bg-white rounded-full shadow-sm"></div>
                </button>
                <div className="w-12 h-12 flex items-center justify-center">
                  {imagePreviews.length > 0 && (
                    <div className="relative">
                      <div className="w-12 h-12 rounded-lg border-2 border-white overflow-hidden bg-slate-800">
                        <img src={imagePreviews[imagePreviews.length - 1]} alt="Last capture" className="w-full h-full object-cover" />
                      </div>
                      <div className="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center border-2 border-white">
                        {imagePreviews.length}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <p className="text-white/80 text-sm mt-4 font-medium">
                برای ثبت عکس‌های بیشتر، دوباره دکمه را لمس کنید
              </p>
            </div>
          </div>
        )}

        {activeTab === 'home' ? (
          <div className="flex flex-col items-center justify-center py-12 sm:py-24 text-center animate-in fade-in duration-500">
            <div className="bg-indigo-100 p-5 rounded-full mb-6 shadow-sm">
              <Camera className="w-12 h-12 text-indigo-600" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">سامانه ثبت گزارش تصویری</h2>
            <p className="text-lg text-slate-600 mb-10 max-w-xl leading-relaxed">
              مشاهدات، مشکلات و اتفاقات پیرامون خود را به سادگی و همراه با تصویر ثبت کنید تا در سریع‌ترین زمان ممکن رسیدگی شود.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <button
                onClick={() => setActiveTab('new')}
                className="flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-sm text-lg"
              >
                <PlusCircle className="w-5 h-5" />
                ثبت گزارش جدید
              </button>
              <button
                onClick={() => setActiveTab('list')}
                className="flex items-center justify-center gap-2 px-8 py-4 bg-white text-slate-700 border border-slate-300 rounded-xl font-medium hover:bg-slate-50 transition-colors shadow-sm text-lg"
              >
                <List className="w-5 h-5" />
                پیگیری گزارش‌های من
              </button>
            </div>
          </div>
        ) : activeTab === 'new' ? (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
            <h2 className="text-2xl font-semibold mb-6">ثبت گزارش جدید</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  تصاویر گزارش <span className="text-red-500">*</span>
                </label>
                <div className="mt-1">
                  {(imagePreviews.length > 0 || streamedFrames.length > 0 || recordedFrames.length > 0) ? (
                    <div className="space-y-4">
                      {location ? (
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm text-emerald-700 bg-emerald-50 p-4 rounded-xl border border-emerald-200">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-5 h-5" />
                            <span className="font-medium">موقعیت مکانی شما با موفقیت ثبت شد ({location.lat.toFixed(4)}, {location.lng.toFixed(4)})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <button 
                              type="button"
                              onClick={() => { setTempLocation(location); setIsMapOpen(true); }}
                              className="flex items-center gap-1.5 bg-white text-emerald-700 border border-emerald-200 px-3 py-1.5 rounded-lg hover:bg-emerald-100 transition-colors text-xs font-medium whitespace-nowrap shadow-sm"
                            >
                              تغییر روی نقشه
                            </button>
                            <a 
                              href={`https://nshn.ir/?lat=${location.lat}&lng=${location.lng}`} 
                              target="_blank" 
                              rel="noreferrer"
                              className="flex items-center gap-1.5 bg-emerald-600 text-white px-3 py-1.5 rounded-lg hover:bg-emerald-700 transition-colors text-xs font-medium whitespace-nowrap shadow-sm"
                            >
                              <MapPin className="w-3.5 h-3.5" />
                              مشاهده روی نشان
                            </a>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => { setTempLocation({lat: 35.6892, lng: 51.3890}); setIsMapOpen(true); }}
                          className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors w-full justify-center border-dashed"
                        >
                          <MapPin className="w-5 h-5" />
                          <span className="font-medium">انتخاب موقعیت مکانی روی نقشه</span>
                        </button>
                      )}
                      
                      {/* Sensor Section */}
                      <div className="mt-4">
                        {isSensorActive && sensors ? (
                          <div className="bg-slate-900 rounded-2xl p-4 shadow-inner text-slate-200 text-sm">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <Compass className="w-4 h-4 text-indigo-400" />
                                <span className="font-medium">اطلاعات ژیروسکوپ و قطب‌نما</span>
                              </div>
                              <button type="button" onClick={stopSensors} className="text-red-400 hover:text-red-300 text-xs">
                                توقف
                              </button>
                            </div>
                            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 font-mono text-center">
                              <div className="bg-slate-800 rounded-lg p-2">
                                <div className="text-slate-400 text-[10px] mb-1">X (Pitch)</div>
                                <div dir="ltr">{sensors.x.toFixed(2)}°</div>
                              </div>
                              <div className="bg-slate-800 rounded-lg p-2">
                                <div className="text-slate-400 text-[10px] mb-1">Y (Roll)</div>
                                <div dir="ltr">{sensors.y.toFixed(2)}°</div>
                              </div>
                              <div className="bg-slate-800 rounded-lg p-2">
                                <div className="text-slate-400 text-[10px] mb-1">Z (Yaw)</div>
                                <div dir="ltr">{sensors.z.toFixed(2)}°</div>
                              </div>
                              <div className="bg-slate-800 rounded-lg p-2">
                                <div className="text-slate-400 text-[10px] mb-1">جهت (قطب‌نما)</div>
                                <div className={sensors.heading !== null ? 'text-emerald-400' : 'text-slate-500'} dir="ltr">
                                  {sensors.heading !== null ? `${sensors.heading.toFixed(2)}°` : 'نامشخص'}
                                </div>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={startSensors}
                            className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors w-full justify-center border-dashed"
                          >
                            <Compass className="w-5 h-5" />
                            <span className="font-medium">ثبت اطلاعات ژیروسکوپ و قطب‌نما</span>
                          </button>
                        )}
                      </div>

                      {recordedFrames.length > 0 && (
                        <div className="bg-slate-900 rounded-2xl p-4 shadow-inner overflow-hidden relative">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2 text-slate-200">
                              <Film className="w-4 h-4 text-indigo-400" />
                              <span className="text-sm font-medium">سکانس‌های ضبط شده (۴ فریم/ثانیه)</span>
                            </div>
                            <span className="text-xs font-mono bg-slate-800 text-slate-400 px-2 py-1 rounded-md">
                              {recordedFrames.length} فریم
                            </span>
                          </div>
                          <div className="flex gap-2 overflow-x-auto pb-4 snap-x [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-slate-800 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-500 [&::-webkit-scrollbar-thumb]:rounded-full">
                            {recordedFrames.map((frame, idx) => (
                              <div key={idx} className="relative flex-shrink-0 snap-start group">
                                <img src={frame.image} className="h-24 w-16 sm:h-28 sm:w-20 object-cover rounded-md border border-slate-700 group-hover:border-indigo-500 transition-colors" alt={`Frame ${idx}`} />
                                <div className="absolute bottom-1 right-1 bg-black/60 text-[10px] text-white px-1 rounded backdrop-blur-sm">
                                  {(idx / 4).toFixed(1)}s
                                </div>
                                {frame.sensors && (
                                  <div className="absolute top-1 left-1 bg-black/60 text-[8px] text-emerald-400 px-1 rounded backdrop-blur-sm font-mono" dir="ltr">
                                    {frame.sensors.heading ? `${frame.sensors.heading.toFixed(2)}°` : `${frame.sensors.x.toFixed(2)}°`}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {streamedFrames.length > 0 && recordedFrames.length === 0 && (
                        <div className="bg-slate-900 rounded-2xl p-4 shadow-inner overflow-hidden relative">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2 text-slate-200">
                              <Film className="w-4 h-4 text-indigo-400" />
                              <span className="text-sm font-medium">سکانس‌های ضبط شده (۴ فریم/ثانیه)</span>
                            </div>
                            <span className="text-xs font-mono bg-slate-800 text-slate-400 px-2 py-1 rounded-md">
                              {streamedFrames.length} فریم
                            </span>
                          </div>
                          <div className="flex gap-2 overflow-x-auto pb-4 snap-x [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-slate-800 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-500 [&::-webkit-scrollbar-thumb]:rounded-full">
                            {streamedFrames.map((frame, idx) => (
                              <div key={idx} className="relative flex-shrink-0 snap-start group">
                                <img src={frame} className="h-24 w-16 sm:h-28 sm:w-20 object-cover rounded-md border border-slate-700 group-hover:border-indigo-500 transition-colors" alt={`Frame ${idx}`} />
                                <div className="absolute bottom-1 right-1 bg-black/60 text-[10px] text-white px-1 rounded backdrop-blur-sm">
                                  {(idx / 4).toFixed(1)}s
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                        {imagePreviews.map((img, idx) => (
                          <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border-2 border-slate-200 group">
                            <img
                              src={img}
                              alt={`Preview ${idx + 1}`}
                              className="object-cover w-full h-full bg-slate-100"
                              referrerPolicy="no-referrer"
                            />
                            <button
                              type="button"
                              onClick={() => setImagePreviews(prev => prev.filter((_, i) => i !== idx))}
                              className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-700 shadow-sm"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() => startCamera()}
                          className="flex flex-col items-center justify-center gap-2 aspect-square border-2 border-indigo-200 border-dashed rounded-xl bg-indigo-50 hover:bg-indigo-100 hover:border-indigo-300 transition-colors text-indigo-700"
                        >
                          <PlusCircle className="w-6 h-6" />
                          <span className="text-xs font-medium">عکس جدید</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => startCamera()}
                      className="w-full flex flex-col items-center justify-center gap-3 p-8 border-2 border-indigo-200 border-dashed rounded-xl bg-indigo-50 hover:bg-indigo-100 hover:border-indigo-300 transition-colors text-indigo-700"
                    >
                      <div className="p-4 bg-white rounded-full shadow-sm">
                        <Camera className="w-10 h-10" />
                      </div>
                      <span className="font-medium text-lg">باز کردن دوربین برای عکس‌برداری</span>
                      <span className="text-sm text-indigo-500">می‌توانید چندین عکس ثبت کنید</span>
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="title" className="block text-sm font-medium text-slate-700 mb-2">
                  عنوان گزارش <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="block w-full rounded-xl border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-3 border bg-slate-50"
                  placeholder="مثال: خرابی لوله آب در طبقه دوم"
                  required
                />
              </div>

              <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
                  توضیحات تکمیلی
                </label>
                <textarea
                  id="description"
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="block w-full rounded-xl border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-3 border bg-slate-50"
                  placeholder="جزئیات بیشتری در مورد این گزارش بنویسید..."
                />
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={!title || (imagePreviews.length === 0 && streamedFrames.length === 0 && recordedFrames.length === 0)}
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
                >
                  ثبت و ارسال گزارش
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold mb-6">گزارش‌های ثبت شده</h2>
            {reports.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 border-dashed">
                <ImageIcon className="mx-auto h-12 w-12 text-slate-300 mb-4" />
                <h3 className="text-lg font-medium text-slate-900">هیچ گزارشی یافت نشد</h3>
                <p className="mt-1 text-slate-500">شما هنوز هیچ گزارشی ثبت نکرده‌اید.</p>
                <button
                  onClick={() => setActiveTab('new')}
                  className="mt-6 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  <PlusCircle className="ml-2 -mr-1 h-5 w-5" aria-hidden="true" />
                  ثبت اولین گزارش
                </button>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2">
                {reports.map((report) => (
                  <div key={report.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col group">
                    <div className="relative aspect-video bg-slate-100">
                      {report.imageUrls.length > 0 ? (
                        <img
                          src={report.imageUrls[0]}
                          alt={report.title}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : report.recordedFrames && report.recordedFrames.length > 0 ? (
                        <img
                          src={report.recordedFrames[0].image}
                          alt={report.title}
                          className="w-full h-full object-cover opacity-90"
                          referrerPolicy="no-referrer"
                        />
                      ) : report.streamedFrames && report.streamedFrames.length > 0 ? (
                        <img
                          src={report.streamedFrames[0]}
                          alt={report.title}
                          className="w-full h-full object-cover opacity-90"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-400">
                          <ImageIcon className="w-8 h-8" />
                        </div>
                      )}
                      
                      {report.imageUrls.length > 0 && (
                        <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md flex items-center gap-1">
                          <ImageIcon className="w-3 h-3" />
                          {report.imageUrls.length} تصویر
                        </div>
                      )}
                      {report.recordedFrames && report.recordedFrames.length > 0 && report.imageUrls.length === 0 && (
                        <div className="absolute bottom-2 right-2 bg-indigo-600/90 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                          <Film className="w-3 h-3" />
                          {report.recordedFrames.length} فریم
                        </div>
                      )}
                      {report.streamedFrames && report.streamedFrames.length > 0 && report.imageUrls.length === 0 && !report.recordedFrames && (
                        <div className="absolute bottom-2 right-2 bg-indigo-600/90 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                          <Film className="w-3 h-3" />
                          {report.streamedFrames.length} فریم
                        </div>
                      )}
                      {report.location && (
                        <div className="absolute top-2 right-2 bg-emerald-500/90 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                          <MapPin className="w-3 h-3" />
                          مکان ثبت شده
                        </div>
                      )}
                      <button
                        onClick={() => handleDelete(report.id)}
                        className="absolute top-3 left-3 p-2 bg-white/90 backdrop-blur-sm text-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50"
                        title="حذف گزارش"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-lg font-semibold text-slate-900 line-clamp-1">{report.title}</h3>
                      </div>
                      <p className="text-slate-600 text-sm line-clamp-2 mb-4 flex-1">
                        {report.description || 'بدون توضیحات'}
                      </p>
                      {report.recordedFrames && report.recordedFrames.length > 0 && (
                        <div className="mb-4 bg-slate-50 rounded-xl p-3 border border-slate-100">
                          <div className="flex items-center gap-1.5 mb-2 text-slate-600">
                            <Film className="w-3.5 h-3.5" />
                            <span className="text-xs font-medium">توالی فریم‌ها ({report.recordedFrames.length})</span>
                          </div>
                          <div className="flex gap-1.5 overflow-x-auto pb-3 [&::-webkit-scrollbar]:h-1.5 [&::-webkit-scrollbar-track]:bg-slate-200 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-400 [&::-webkit-scrollbar-thumb]:rounded-full">
                            {report.recordedFrames.map((frame, idx) => (
                              <div key={idx} className="relative flex-shrink-0">
                                <img src={frame.image} className="h-16 w-12 object-cover rounded-sm border border-slate-300" alt={`Frame ${idx}`} />
                                {frame.sensors && (
                                  <div className="absolute top-0.5 left-0.5 bg-black/60 text-[7px] text-emerald-400 px-1 rounded backdrop-blur-sm font-mono" dir="ltr">
                                    {frame.sensors.heading ? `${frame.sensors.heading.toFixed(2)}°` : `${frame.sensors.x.toFixed(2)}°`}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {report.streamedFrames && report.streamedFrames.length > 0 && !report.recordedFrames && (
                        <div className="mb-4 bg-slate-50 rounded-xl p-3 border border-slate-100">
                          <div className="flex items-center gap-1.5 mb-2 text-slate-600">
                            <Film className="w-3.5 h-3.5" />
                            <span className="text-xs font-medium">توالی فریم‌ها ({report.streamedFrames.length})</span>
                          </div>
                          <div className="flex gap-1.5 overflow-x-auto pb-3 [&::-webkit-scrollbar]:h-1.5 [&::-webkit-scrollbar-track]:bg-slate-200 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-400 [&::-webkit-scrollbar-thumb]:rounded-full">
                            {report.streamedFrames.map((frame, idx) => (
                              <img key={idx} src={frame} className="h-16 w-12 object-cover rounded-sm border border-slate-300 flex-shrink-0" alt={`Frame ${idx}`} />
                            ))}
                          </div>
                        </div>
                      )}
                      {report.sensors && (
                        <div className="mb-4 bg-slate-50 rounded-xl p-3 border border-slate-100">
                          <div className="flex items-center gap-1.5 mb-2 text-slate-600">
                            <Compass className="w-3.5 h-3.5" />
                            <span className="text-xs font-medium">اطلاعات سنسورها</span>
                          </div>
                          <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
                            <div className="bg-white border border-slate-200 rounded p-1.5">
                              <div className="text-slate-400 text-[9px]">X</div>
                              <div className="text-slate-700" dir="ltr">{report.sensors.x.toFixed(2)}°</div>
                            </div>
                            <div className="bg-white border border-slate-200 rounded p-1.5">
                              <div className="text-slate-400 text-[9px]">Y</div>
                              <div className="text-slate-700" dir="ltr">{report.sensors.y.toFixed(2)}°</div>
                            </div>
                            <div className="bg-white border border-slate-200 rounded p-1.5">
                              <div className="text-slate-400 text-[9px]">Z</div>
                              <div className="text-slate-700" dir="ltr">{report.sensors.z.toFixed(2)}°</div>
                            </div>
                            <div className="bg-white border border-slate-200 rounded p-1.5">
                              <div className="text-slate-400 text-[9px]">قطب‌نما</div>
                              <div className="text-slate-700" dir="ltr">{report.sensors.heading !== null ? `${report.sensors.heading.toFixed(2)}°` : '-'}</div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="text-xs text-slate-400 flex items-center justify-between mt-auto pt-3 border-t border-slate-100">
                        <span>
                          {new Date(report.timestamp).toLocaleDateString('fa-IR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                        {report.location && (
                          <a 
                            href={`https://nshn.ir/?lat=${report.location.lat}&lng=${report.location.lng}`} 
                            target="_blank" 
                            rel="noreferrer"
                            className="flex items-center gap-1 text-indigo-600 hover:text-indigo-700 transition-colors font-medium"
                          >
                            <MapPin className="w-3 h-3" />
                            مشاهده روی نشان
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {isMapOpen && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl overflow-hidden flex flex-col h-[80vh]">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-indigo-600" />
                انتخاب موقعیت روی نشان (نقشه)
              </h3>
              <button onClick={() => setIsMapOpen(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 relative bg-slate-100" dir="ltr">
              <MapContainer center={tempLocation || {lat: 35.6892, lng: 51.3890}} zoom={13} style={{ height: '100%', width: '100%' }}>
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <LocationMarker position={tempLocation} setPosition={setTempLocation} />
              </MapContainer>
              <div className="absolute top-4 right-4 z-[400] bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-md text-sm font-medium text-slate-700 border border-slate-200" dir="rtl">
                برای انتخاب موقعیت، روی نقشه کلیک کنید
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsMapOpen(false)}
                className="px-5 py-2.5 rounded-xl font-medium text-slate-700 hover:bg-slate-200 transition-colors"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={() => {
                  if (tempLocation) {
                    setLocation(tempLocation);
                    setIsMapOpen(false);
                  }
                }}
                disabled={!tempLocation}
                className="px-5 py-2.5 rounded-xl font-medium text-white bg-indigo-600 hover:bg-indigo-700 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed shadow-sm"
              >
                تایید موقعیت
              </button>
            </div>
          </div>
        </div>
      )}

      {showPermissionModal && (
        <div className="fixed inset-0 z-[200] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center animate-in zoom-in duration-300">
            <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-3">دسترسی‌های مورد نیاز</h3>
            <div className="text-slate-600 text-sm leading-relaxed mb-6 text-right">
              برای عملکرد صحیح، این برنامه نیاز به دسترسی‌های زیر دارد:
              <br/><br/>
              <div className="flex items-center gap-2 mb-2"><Camera className="w-4 h-4 text-indigo-500"/> <strong>دوربین:</strong> برای ثبت تصاویر گزارش</div>
              <div className="flex items-center gap-2 mb-2"><MapPin className="w-4 h-4 text-emerald-500"/> <strong>موقعیت مکانی:</strong> برای ثبت دقیق محل</div>
              <div className="flex items-center gap-2 mb-4"><Compass className="w-4 h-4 text-amber-500"/> <strong>سنسورها:</strong> برای ثبت زاویه و جهت</div>
              لطفاً در پیام‌های بعدی مرورگر، این دسترسی‌ها را تأیید کنید.
            </div>
            <button
              onClick={handleGrantPermissions}
              disabled={isRequestingPermissions}
              className="w-full py-3.5 px-4 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-sm text-lg disabled:bg-indigo-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isRequestingPermissions ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  در حال دریافت مجوزها...
                </>
              ) : (
                'متوجه شدم و تأیید می‌کنم'
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
