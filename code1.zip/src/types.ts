export interface FrameData {
  image: string;
  sensors: {
    x: number;
    y: number;
    z: number;
    heading: number | null;
  } | null;
}

export interface Report {
  id: string;
  title: string;
  description: string;
  imageUrls: string[];
  streamedFrames?: string[];
  recordedFrames?: FrameData[];
  location?: { lat: number, lng: number } | null;
  sensors?: {
    x: number;
    y: number;
    z: number;
    heading: number | null;
  } | null;
  timestamp: number;
}
